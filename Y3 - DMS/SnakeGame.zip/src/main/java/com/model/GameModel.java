package com.model;

public class GameModel {
	public static final int SCREEN_SIZE = 600+100;
	public static int GAME_SIZE=20;
	public static int GAME_UNITS=(SCREEN_SIZE-100)/GAME_SIZE;
	
	public static String GAMETITLE="Snake";
	

	public static String BGCOLOR="black";
}
